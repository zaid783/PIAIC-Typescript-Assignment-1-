/////////question////////
var name = "hello hammad,";
console.log(name,'would you like to learn some python today?')