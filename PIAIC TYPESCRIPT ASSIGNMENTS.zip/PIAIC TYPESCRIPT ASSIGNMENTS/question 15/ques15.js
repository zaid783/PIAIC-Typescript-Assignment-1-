var name = ['zaid', 'owais', 'hammad', 'arsalan'];
var cannotmakeit = 'zaid';
console.log('sorry our one guest is not come his name is ' + cannotmakeit);
var newguest = "shozab";
name[0] = newguest;
// const message = "HI you're invited to my dinner party tonight with your family {names}"
for (var _i = 0, name_1 = name; _i < name_1.length; _i++) {
    var names = name_1[_i];
    console.log('Hi , im inviting you to dinner mr' + newguest);
}
