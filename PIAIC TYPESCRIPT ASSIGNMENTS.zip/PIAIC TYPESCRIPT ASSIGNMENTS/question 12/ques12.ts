// const name=['zaid','owais','hammad','arsalan']
// const messgae = "hello how are you {names}";
// for(const names of name){
//     console.log(messgae.replace("{names}",names));
// }

var favnum = "hammad";
var message = "hello how are you"
console.log(message,'hammad');
var favnum = "owais";
var message = "hello how are you"
console.log(message,'owais');
var favnum = "zaid";
var message = "hello how are you"
console.log(message,'zaid');





