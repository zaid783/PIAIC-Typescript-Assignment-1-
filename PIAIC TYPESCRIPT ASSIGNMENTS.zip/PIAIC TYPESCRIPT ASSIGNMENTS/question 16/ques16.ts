const guests = ['ahmed','zaid','owais','hammad']
console.log('i found a bigger dining table');

guests.unshift('arsalan');
guests.splice(0,2,'shozab');
guests.push('ali');
for(const guest of guests){
    console.log('hi,' +guest, 'im inviting you to the dinner party');
}
