const vehicles = ['bike','car','aeroplane','ship']
const state = "i want to drive a {veh}";
for(const veh of vehicles){
    console.log(state.replace("{veh}",veh));
}