const number_of_guest = '4';
console.log("the number of guests i invited is : " +  number_of_guest)