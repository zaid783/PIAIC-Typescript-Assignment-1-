////////question5////////

var namewhitespace = "t/PIAIC/n";
console.log("name with white space:",namewhitespace);

var striping = namewhitespace.trim()
console.log("after striping the white spaces:",striping)
