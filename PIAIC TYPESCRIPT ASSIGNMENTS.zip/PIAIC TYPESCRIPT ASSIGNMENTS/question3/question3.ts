////////question///////

 var poet = "Mohammad iqbal once said"
 var quotation = "the ultimate aim of the ego is not to se something, but to be something"
 console.log(poet,quotation)