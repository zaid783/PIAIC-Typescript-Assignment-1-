function describe_country(city,country){
    console.log(city + " is the capital of " + country);
}
describe_country('Karachi','Pakistan');
describe_country('Delhi','India');
describe_country('London','UK')