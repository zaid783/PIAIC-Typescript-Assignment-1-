const pizza = ['California','Broadway','PizzaMax']
for(const pizz of pizza){
    const messages = "i like the pizza of " + pizz;
    console.log(messages); 
}