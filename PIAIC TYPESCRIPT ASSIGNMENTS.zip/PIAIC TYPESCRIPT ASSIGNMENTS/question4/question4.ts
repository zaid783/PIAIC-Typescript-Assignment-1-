////////question4//////

var famous_name = "quaid_e_azam"
var massage = "is the famous person";
console.log(famous_name,massage);