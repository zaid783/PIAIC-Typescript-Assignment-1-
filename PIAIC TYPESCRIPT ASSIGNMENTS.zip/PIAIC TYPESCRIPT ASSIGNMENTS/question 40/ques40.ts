function make_album(artist,title,tracks= undefined){
    const album ={
        artist:artist,
        title:title,
    };
    if(tracks !== undefined){
        album.tracks = tracks;
    }
    return album;
}
const album1 = make_album("The Beatles", "Rubber Soul");
const album2 = make_album("Pink Floyd", "The Dark Side of the Moon", 13);
const album3 = make_album("Radiohead", "OK Computer", 12);

console.log(album1);
console.log(album2);
console.log(album3);