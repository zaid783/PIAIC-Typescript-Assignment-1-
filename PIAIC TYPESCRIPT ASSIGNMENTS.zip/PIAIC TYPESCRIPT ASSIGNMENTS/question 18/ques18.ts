const placetovisit = ['madina','makkah','europe','middle east']
console.log('**this are the places that i want to visited');
console.log(placetovisit);

//print the array in sorted way//
const sortedplaced = placetovisit.sort();
console.log("**here are the places which i want to visited in sorted way")
console.log(sortedplaced);

//in original way//
const placetovisits=placetovisit
console.log("**places to visited is still in orignal sorted manner")
console.log(placetovisits);

//print the array in reverse order//
const reverseorder = placetovisit.reverse();
console.log("**the places i want to visit is in reverse order")
console.log(reverseorder);

//in original way//
console.log("**the array still in original order");
console.log(placetovisit);

//reverse the array again//
placetovisit.reverse();
console.log("**the array is reverse");
console.log(placetovisit);

//reverse the array again//
placetovisit.reverse();
console.log("**the array is reverse again ");
console.log(placetovisit);

//sorting the array of list//
placetovisit.sort();
console.log("**the array of the visited place is sorted");
console.log(placetovisit);

//sort the array then reverse and print to it//
const sorted =placetovisit.sort();
console.log("**the sorted array");
console.log(sorted);

sorted.reverse();
console.log("**after sorting there is reverse order of it.")
console.log(sorted);