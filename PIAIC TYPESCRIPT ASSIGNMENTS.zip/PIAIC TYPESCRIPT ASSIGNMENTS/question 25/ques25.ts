var alien_color1 = 'green';
if(alien_color1 === 'green'){
    console.log(" player just earned 5 points.");
} else{
    console.log("player does not earned 5 points.")
}
//this is for false statement means "else statement is succesfull here".//
alien_color1 = 'yellow';
if(alien_color1 == 'green'){
    console.log("player just earned 5 points.");
} else{
    console.log("player does not earned 5 points.");
}

