const testEqualityAndInequalityWithStrings = () => {
    const st1 = 'hello';
    const st2 = 'hello';
    const st3 = 'world';

    console.log(st1 == st2);
    console.log(st3 != st3);
};

const lower_case_function = () => {
    const str1 = "Hello"
    const str2 = str1.toLowerCase();

    console.log("str1.tolowercase() == 'hello' : " +(str2 == "hello"));
}

const test_and_or = () =>{
    const num1 = 5;
    const num2 = 10;

    console.log(" (num1 == 5) && (num2 == 10): " + ((num1 == 6) && (num2 == 10)));
    console.log(" (num1 == 5) || (num2 == 10): " + ((num1 == 5) || (num2 == 10)));
}

const item_in_array =() => {
    const array = [1,2,3,4,5,6,7,8,9];
    console.log("check 2 in array :"+((2 in array)));
    console.log("check 6 in array :"+((10 in array)));
}


const item_not_in_array =() => {
    const array2 = [1,2,3,4,5,6,7,8,9];
    console.log("check 10 is in array :"+((10 in array2)));
    console.log("check 5 is in array :"+((5 in array2)));
}


testEqualityAndInequalityWithStrings();
lower_case_function();
test_and_or();
item_in_array();
item_not_in_array();