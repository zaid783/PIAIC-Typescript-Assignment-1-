function make_shirt(size = 'large', message = 'i love TypeScript'){
    console.log("the shirt size is " + size + " and the message print on it is " + message);
}
make_shirt();
make_shirt("medium","i love python");
make_shirt("small",'i love javascript');