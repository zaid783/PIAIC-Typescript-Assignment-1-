////////question/////////


console.log("additon",4+4);
console.log("substraction",12-8);
console.log("multiplication",4*2)
console.log("division",16/2)