/////////question2/////////

var name = "hammadullah"
console.log(name.toUpperCase())
console.log(name.toLowerCase())
 function toTitleCase(name) {return name .split(' ') .map(w =>w[0].toUpperCase()+ w.substring(1).toLowerCase()).join('');}
 console.log(toTitleCase(name));