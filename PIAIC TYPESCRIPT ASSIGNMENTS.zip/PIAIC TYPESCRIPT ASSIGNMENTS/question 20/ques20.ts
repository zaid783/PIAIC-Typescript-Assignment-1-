const thinking_the_places = ['mountains','hills','forests']
console.log("the places i was thinking right now");
console.log(thinking_the_places);