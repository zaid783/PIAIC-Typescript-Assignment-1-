const guests = ['ahmed','zaid','owais','hammad']
console.log("sorry due to tbale issue of because it's not arrive on time so i invite only two guest");
while(guests.length >2){
    const guest = guests.pop();
    console.log("sorry"   +  guest  +   "you're not invited to dinner party :( ")
}
for(const guest of guests){
    console.log('hi'   +  guest  +   'you are still invited to dinner party');
}
guests.pop();
guests.pop();

console.log(guests);
