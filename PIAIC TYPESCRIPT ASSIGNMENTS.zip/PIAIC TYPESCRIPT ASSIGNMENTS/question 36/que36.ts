function make_shirt(size, message){
    console.log(" please made a  " + size +" size shirt " + " and write " + message + " on it! ");
}
make_shirt("large","i love programming");