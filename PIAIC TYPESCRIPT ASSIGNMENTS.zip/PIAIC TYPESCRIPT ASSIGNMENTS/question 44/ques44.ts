function makeSandwich(items) {
  console.log("Your sandwich will have the following items:");
  for (const item of items) {
    console.log(item);
  }
}

// Call the function with one argument.
makeSandwich(["ham", "cheese"]);

// Call the function with two arguments.
makeSandwich(["ham", "cheese", "lettuce"]);

// Call the function with three arguments.
makeSandwich(["ham", "cheese", "lettuce", "tomato"]);
