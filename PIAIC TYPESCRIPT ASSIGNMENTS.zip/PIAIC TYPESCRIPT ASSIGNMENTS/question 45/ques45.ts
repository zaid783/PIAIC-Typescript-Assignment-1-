function carInfo(manufacturer, model,kwargs) {
    const car = {
      manufacturer: manufacturer,
      model: model,
    };
    for (const [key, value] of kwargs) {
      car[key] = value;
    }
    return car;
  }
  
  const car = carInfo("Tesla", "Model S", color="red", sunroof=true);
  
  console.log(car);
  