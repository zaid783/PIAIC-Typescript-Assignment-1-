//////question8//////


var favnum = "4";
console.log('my favourite number is', favnum);


