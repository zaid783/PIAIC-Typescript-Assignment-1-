const animal = ['lion','cat','leopards']
for(const ani of animal){
    const message = ani + " is the carnivorious animals and it's has the same similarities";
    console.log(message);
}