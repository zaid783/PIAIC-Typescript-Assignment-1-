//error recived in this array because it is out of bond//
const num = [1,2,3,4,5,6,7]
console.log(num[7]);

//correct array is//
const numbers = [1,2,3,4,5,6,7,8]
console.log(numbers[7]);