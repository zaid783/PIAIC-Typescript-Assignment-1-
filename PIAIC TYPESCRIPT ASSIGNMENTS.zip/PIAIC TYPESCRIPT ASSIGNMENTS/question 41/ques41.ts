const magician_name = ['harry poter','charlie poter','jhonson poter']
function magician(magician_name){
    for (const magician_names of magician_name){
        console.log(magician_names)
    }
}
magician(magician_name);