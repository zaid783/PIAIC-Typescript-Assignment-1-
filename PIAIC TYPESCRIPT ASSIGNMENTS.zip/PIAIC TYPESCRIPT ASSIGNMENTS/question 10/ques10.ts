//const name1 = 'zaid'//
//console.log("my name is "+name1);//