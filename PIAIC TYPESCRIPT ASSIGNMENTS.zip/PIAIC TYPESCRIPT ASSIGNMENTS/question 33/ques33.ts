const arr = [1,2,3,4,5,6,7,8,9]
for(const arra of arr){
    let ordinal_number = "th";
    if(arra==1){
        ordinal_number="st";
    }else if (arra==2){
        ordinal_number="nd";
    }else if(arra==3){
        ordinal_number="rd"
    }else {
        ordinal_number="th"
    }
    console.log(arra,ordinal_number);
}