//first version//
var alien_colors = 'green';

if(alien_colors == 'green'){
    console.log("player just earned 5 points")
} else if(alien_colors == 'yellow'){
    console.log("player just earned 10 points.")
} else if(alien_colors == 'red'){
    console.log('player just earned 15 points')
} else{
    console.log("player earned nothing")
}

//second version//
var alien_colorss = 'yellow';

if(alien_colorss == 'green'){
    console.log("player just earned 5 points")
} else if(alien_colorss == 'yellow'){
    console.log("player just earned 10 points.")
} else if(alien_colorss == 'red'){
    console.log('player just earned 15 points')
} else{
    console.log("player earned nothing")
}

//third version//
var alien_colorsss = 'red';
if(alien_colorsss == 'green'){
    console.log("player just earned 5 points")
} else if(alien_colorsss == 'yellow'){
    console.log("player just earned 10 points.")
} else if(alien_colorsss == 'red'){
    console.log('player just earned 15 points')
} else{
    console.log("player earned nothing")
}