var alien_color = 'green'
if(alien_color == 'green'){
    console.log("player just earned 5 points")
}else{
    console.log("player just earned 10 points")
}

alien_color = 'yellow'
if(alien_color == 'green'){
    console.log("player jsut earned 5 points")
} else{
    console.log("player just earned 10 points")
}