const name = ['zaid','owais','hammad','arsalan'];
const cannotmakeit= 'zaid';
console.log('sorry our one guest is not come his name is '+cannotmakeit);
const newguest = "shozab";
name[0]=newguest;

// const message = "HI you're invited to my dinner party tonight with your family {names}"

for(const names of name){
    console.log('Hi , im inviting you to dinner mr'+newguest);
}