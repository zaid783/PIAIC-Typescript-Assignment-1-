const makeGreat = (magicians) => {
    const greatMagicians = [];
    for (const magician of magicians) {
      const greatMagician = magician + " the Great";
      greatMagicians.push(greatMagician);
    }
    return greatMagicians;
  };
  
  const showMagicians = (magicians) => {
    for (const magician of magicians) {
      console.log(magician);
    }
  };
  
  const magicians = ['harry poter','charlie poter','jhonson poter'];
  
  const greatMagicians = makeGreat(magicians);
  
  console.log("The original magicians:");
  showMagicians(magicians);
  
  console.log("The great magicians:");
  showMagicians(greatMagicians);
  