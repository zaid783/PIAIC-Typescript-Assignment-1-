let person = {
    name: 'zaid',
    age: '20',
    gender: 'male'
}
console.log("person name is " + person.name + " and age is " + person.age + " and the gender is " +person.gender);