//five true statements//
let car = 'subaru';
console.log("is car == 'subaru' ? | predict True.")
console.log(car=='subaru');

let bike = "honda";
console.log("is bike == honda ?  | predict True.")
console.log(bike=='honda');

let ship = 'titanic';
console.log("is ship == titanic ?  | predict True.")
console.log(ship=='titanic');

let aeroplane = 'airbusA380'
console.log("is aeroplane == airbusA380 ?  | predict True.")
console.log(aeroplane=='airbusA380');

let carlenght = '3'
console.log("car.lenght == 3 ?  | predict True.")
console.log(carlenght=='3');


//five false statements//
console.log("is aeroplane =='airbus'? I predict False.")
console.log(aeroplane=='airbus');

console.log("is car =='toyota'? I predict False.");
console.log(car=='toyota');

console.log("car.lenght == '7'? I predict False.")
console.log(carlenght=='7');

console.log("ship == 'boat'? I predict False.")
console.log(ship=='boat');

console.log("bike == 'unique'? I predict False.")
console.log(bike=='unique');