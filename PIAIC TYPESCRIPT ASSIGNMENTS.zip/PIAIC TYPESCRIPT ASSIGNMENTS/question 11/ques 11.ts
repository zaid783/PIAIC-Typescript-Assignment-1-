const name=['zaid','owais','hammad','arsalan']
for(const names of name){
    console.log(names)
}