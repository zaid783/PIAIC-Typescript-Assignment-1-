const current_user =['zaid','hammad','owais','shozab','arsalan']
const new_user = ['zaid','hammad','ali','umar','usman']

for (const new_users of new_user){
    const found = current_user.some((current_user)=> current_user.toLowerCase() == new_users.toLowerCase());

    if (found){
        const message = "the username " + new_users + "  is already taken please enter a new user_name";
        console.log(message);
    }else{
        const message = "the username " + new_users + "  is available";
        console.log(message);
    }
}