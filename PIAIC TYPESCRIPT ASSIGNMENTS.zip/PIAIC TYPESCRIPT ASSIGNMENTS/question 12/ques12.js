var name = ['zaid', 'owais', 'hammad', 'arsalan'];
var messgae = "hello how are you {name}";
for (var _i = 0, name_1 = name; _i < name_1.length; _i++) {
    var names = name_1[_i];
    console.log(messgae.replace("{name}", name));
}
