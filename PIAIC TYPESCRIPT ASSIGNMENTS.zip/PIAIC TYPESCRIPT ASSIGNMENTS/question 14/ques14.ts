const name = ['zaid','owais','hammad','arsalan']
const message = "HI you're invited to my dinner party tonight with your family {names}"
for(const names of name){
    console.log(message.replace("{names}",names))
}

// var name = ("zaid");
// var massage = "HI you're invited to my dinner party tonight with your family"
// console.log(massage,'zaid');
// var name = ("zaid");
// var massage = "HI you're invited to my dinner party tonight with your family"
// console.log(massage,'zaid');
// var name = ("zaid");
// var massage = "HI you're invited to my dinner party tonight with your family"
// console.log(massage,'zaid');
// var name = ("zaid");
// var massage = "HI you're invited to my dinner party tonight with your family"
// console.log(massage,'zaid');