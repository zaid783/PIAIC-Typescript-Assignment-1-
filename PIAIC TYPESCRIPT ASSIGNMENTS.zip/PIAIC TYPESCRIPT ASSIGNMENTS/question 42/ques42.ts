const magicians = ['harry poter','charlie poter','jhonson poter'];
function make_great(magicians){
    const great_magician = magicians.map((magicians) => 'The Greate ' + magicians );
    return great_magician;
}
const original_magicians = magicians;
const great_magician = make_great(magicians.slice());

console.log(original_magicians);
console.log(great_magician);

