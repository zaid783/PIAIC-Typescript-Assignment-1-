function city_country(city,country){
    console.log(city + " , " + country);
}
city_country('Karachi','Pakistan');
city_country('Dubai','UAE');
city_country('Paris','France');