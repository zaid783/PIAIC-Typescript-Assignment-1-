const favorite_fruits = ['mango','apple','grapes','bananas','peach']

if(favorite_fruits.includes("mago")){
    console.log("you really like mango! ")
} if(favorite_fruits.includes("apple")){
    console.log("you really like apple! ")
} if(favorite_fruits.includes("grapes")){
    console.log("you really like grapes! ")
} if(favorite_fruits.includes("bananas")){
    console.log("you really like bananas! ")
} if(favorite_fruits.includes("peach")){
    console.log("you really like peach! ")
} if(favorite_fruits.includes("pineapple")){
    console.log("you really like pineapple! ")
} if(favorite_fruits.includes("oranges")){
    console.log("you really like oranges")
}

